#include<iostream>
#include "Commands.h"



int main()
{
	Commands commands;
	commands.run();

	

}